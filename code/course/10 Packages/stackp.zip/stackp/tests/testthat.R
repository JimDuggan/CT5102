library(testthat)

test_check("stackp")


